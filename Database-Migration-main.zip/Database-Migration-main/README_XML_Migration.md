# 🛠️ Data Migration Using XML as a Conversion Tool

This project implements a system for **data migration between different database systems** using **XML as an intermediate conversion format**. It supports migrating selected tables across popular relational databases including **MySQL Server**, **PostgreSQL**, **MS Access**, and **SQLite**.

---

## 📌 Project Description

**Data Migration Using XML** is a tool that enables users to:

- Select specific tables from a source database
- Convert table structures and records to a standardized XML format
- Parse the XML and recreate the same schema and data in a target database

The primary goal of this project is to **standardize data transfer** across different RDBMS platforms using XML, ensuring platform-independent portability and ease of transformation.

---

## 🔧 Supported Databases

- ✅ MySQL Server
- ✅ PostgreSQL
- ✅ MS Access
- ✅ SQLite

---

## 🔄 Workflow Overview

1. **User Input**: Source and target DB configuration, and table(s) to migrate
2. **Extraction**: Read schema and data from source DB
3. **Conversion**: Generate structured XML representing the table(s)
4. **Transformation**: Parse the XML to create equivalent tables in target DB
5. **Loading**: Insert extracted data into the target system

---

## 🧰 Tech Stack

- Java (JDBC)
- XML (as intermediary data representation)
- Database Drivers (JDBC connectors for MySQL, PostgreSQL, SQLite, and MS Access)
- Swing or CLI (based on implementation preference)

---

## 📂 Sample XML Format

```xml
<database>
  <table name="books">
    <columns>
      <column name="id" type="INTEGER"/>
      <column name="title" type="VARCHAR"/>
      <column name="author" type="VARCHAR"/>
    </columns>
    <rows>
      <row>
        <id>1</id>
        <title>The Hobbit</title>
        <author>J.R.R. Tolkien</author>
      </row>
    </rows>
  </table>
</database>
```

---

## ⚙️ How to Use

1. **Configure Source DB**: Provide DB type, connection URL, username, and password
2. **Select Tables**: Choose which tables to migrate
3. **Generate XML**: System exports the selected tables to XML
4. **Configure Target DB**: Provide target DB info
5. **Import XML**: Tool parses the XML and replicates data in target DB

---

## ✅ Advantages

- Platform-independent data exchange
- Simplifies complex multi-database migrations
- Useful for backup, archiving, or DB transformation

---

## 📌 Future Enhancements

- Web-based GUI
- Support for more data types and complex constraints
- Integration with cloud databases (e.g., AWS RDS, Firebase SQL)

---

## 🧑‍💻 Author

**Srija Dasgupta**  
✉️ [mamandasgupta@gmail.com](mailto:mamandasgupta@gmail.com)
